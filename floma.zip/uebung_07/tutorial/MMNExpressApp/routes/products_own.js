var express = require('express');
var router = express.Router();

var products = {{ "name": "Product A", "price": 30, "id": "id_A" },
{ "name": "Product B", "price": 50, "id": "id_B" }};
/* GET home page. */
router.get('/', function(req, res, next) {
  res.json({
    code: 200,
    products: products,
  });
});

/* POST home page. */
router.post('/', function(req, res, next) {
  if(products){
    const productName = req.body['name'];
    const productPrice = req.body['price'];

    if(!productName || !productPrice){
      return res.status(400).json({
        status: 400,
        message: 'Parameters missing.',
      });
    }

    const newProduct = {
      name: productName,
      price:productPrice,
      id: "id_C",
    };

    products.push(newProduct);

    res.status(201).json({
      code: 201,
      message: 'product created',
      products: products,
    });
  } else {
    throw new Error('Products not found.');
  }
});

module.exports = router;
