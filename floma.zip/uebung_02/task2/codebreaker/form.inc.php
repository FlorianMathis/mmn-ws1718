<div id="formdiv">
    <form method="post" id="fields">
        <label for="one"></label><input type="text" id="one" name="one" maxlength="1" />
        <label for="two"></label><input type="text" id="two" name="two" maxlength="1" />
        <label for="three"></label><input type="text" id="three" name="three" maxlength="1" />
        <label for="four"></label><input type="text" id="four" name="four" maxlength="1" />
        <input type="submit" value="Check" name="submit" />
    </form>
    <a href="codebreaker.php" class="restart">Restart</a>
</div>
