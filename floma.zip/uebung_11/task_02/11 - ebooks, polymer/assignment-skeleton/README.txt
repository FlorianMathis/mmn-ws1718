Irgendwie waren die Pfade nicht korrekt. 
->   <!-- <base href="https://polygit.org/components/"> --> scheint down zu sein.

