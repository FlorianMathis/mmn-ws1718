Leider ist es mir nicht m�glich, ebook-app.html korrekt aufzurufe (siehe screens).



