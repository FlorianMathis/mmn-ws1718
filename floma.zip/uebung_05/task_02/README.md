# Assignment 05 - jQuery AJAX #
It's probably best if you somehow prefix your folder names with your initials / name / alias

Like so: `darkwingDuck_task01`, `darkwingDuck_task02`... you get the idea 