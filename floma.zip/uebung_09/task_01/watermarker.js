/**
 * Created by Tobi on 17.12.2016.
 */

var express = require('express');
var router = express.Router();
var path = require('path');
var Jimp = require('jimp');
var fs = require('fs');
//var glob = require("glob");

var watermarkedImagesDirectory = path.join(__dirname, '../watermarks');
var publicImagesDirectory = '../public/images';

var watermark; // holds the Jimp image
var watermarkPath = path.join(__dirname, '../public/images/watermark.png');
var errorPath     = path.join(__dirname, '../public/images/sorry.png');

// first, make sure that the directory exists.
if (!fs.existsSync(watermarkedImagesDirectory)) {
  fs.mkdirSync(watermarkedImagesDirectory);
}
Jimp.read(watermarkPath, function (err, img) {
  watermark = img;
  router.use('/', function (req, res, next) {
      if (req.query.url) {
        var markedPath = path.join(watermarkedImagesDirectory, 'img.png');
        Jimp.read(req.query.url, function(err, img) {
          if(err)
            res.sendFile(errorPath);
          else {
            img.composite(watermark, 0, 0, function(err, dst) {
              if(err) res.sendFile(errorPath);
              dst.write(markedPath, function() {
                res.sendFile(markedPath);
                });
              });
            }
        });
      } else {
        res.sendFile(errorPath);
      }
  });
});

module.exports = router;
